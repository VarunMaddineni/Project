package com.wallet.service;

import com.wallet.bean.BankAccount;

public interface IWalletService {
	int addAccDao(BankAccount a);
	double depositDao(double money);
	double withdrawDao(double money) ;
	double showBalDao();
	boolean checkLogin(int accNo);
	boolean checkPassword(String pwd);
	String currentUser();
	boolean transferAmt(int toAccNo, double money);
	public String getTransaction();
}
