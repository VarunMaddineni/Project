package com.wallet.service;

import com.wallet.bean.BankAccount;
import com.wallet.dao.IWalletDao;
import com.wallet.dao.WalletDao;
import com.wallet.exception.WalletException;

public class WalletService implements IWalletService {
	String pt,s=null;
	BankAccount temp = new BankAccount();
	IWalletDao dao;
	 public WalletService() {
		 dao = new WalletDao();
		 
	}
	 
	 static String namePattern = "[A-Z]{1}[a-z]{2,}";
	 static String numberPattern = "(\\d){10}";
	 static String passwordPattern = "[A-Z]{1}[a-z]{2,6}(\\W){1}(\\d){1,4}";
	
	@Override
	public int addAccDao(BankAccount a) {
		
		return dao.accCreation(a);
	}

	@Override
	public double depositDao(double money) {
		temp.setCustBal(temp.getCustBal()+money);
		dao.updateDetails(temp.getAccountNumber(),temp);
		return temp.getCustBal();
	}

	@Override
	public double withdrawDao(double money) {
		if(money<temp.getCustBal()) {
		temp.setCustBal(temp.getCustBal()-money);
		dao.updateDetails(temp.getAccountNumber(),temp);
		}
		else
			System.out.println("Low Balance :( ");
		return temp.getCustBal();
	}

	@Override
	public double showBalDao() {
		
		return temp.getCustBal();
	}
public  boolean validateCustName(String name)
{	if(name.matches(namePattern))
		return true;
	else
		return false;
	
}
public  boolean validateCustPhoneNumber(String number) {
	if(number.matches(numberPattern))
		return true;
	else
		return false;
}

public boolean validateCustAge(int age) {
	if(age<=110&&age>=5)
		return true;
	else
		return false;
	
}

public  boolean validateCustPwd(String pwd) {
	if(pwd.matches(passwordPattern))
		return true;
	else
		return false;
}

public  boolean validateAmt(double amt) {
if(amt>0.00)
	return true;
else
	return false;
}
@Override
public boolean checkLogin(int accNo) {
	try {
		temp =dao.loginUser(accNo);
	} catch (WalletException e) {
		
		e.printStackTrace();
	}
	if(temp!=null)
	return true;
	else 
		return false;
}
@Override
public boolean checkPassword(String pwd) {
	
	if(temp.getCustPwd().matches(pwd))
		return true;
	else
		return false;

	
}

@Override
public String currentUser() {
	
	return temp.getCustName();
}

@Override
public boolean transferAmt(int toAccNo, double money) {
	
	BankAccount ftTemp =new BankAccount();
	if(temp.getCustBal()>=money) {
	try {
		ftTemp = dao.loginUser(toAccNo);
	} catch (WalletException e) {
		
		e.printStackTrace();
	}
	if(ftTemp!=null)
	{
		int id = temp.getAccountNumber();
		if(temp.getTransaction()==null) {
			temp.setTransaction("Account No: " +id+ " amount "+money+ " trnferred to "+ftTemp.getAccountNumber());
		}
		else {
			pt = temp.getTransaction();
			s=" Account No: "+id+" amount "+money+ " transferred to "+ftTemp.getAccountNumber() + "\n";
			pt+=s;
			temp.setTransaction(pt);
		} 
		ftTemp.setCustBal(ftTemp.getCustBal()+money);
		temp.setCustBal(temp.getCustBal()-money);
		dao.updateDetails(temp.getAccountNumber(), temp);
		dao.updateDetails(ftTemp.getAccountNumber(), ftTemp);
		return true;
	}
	
	
}
	else if(temp.getCustBal()<money)
	{
		System.out.println("No Sufficient Balance to transfer");
	}
	
	else
		System.out.println("No such user account");
	return false;
}

@Override
public String getTransaction() {
	String p=temp.getTransaction();
	return p;
}
}
