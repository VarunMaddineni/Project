package com.wallet.test;

import org.junit.jupiter.api.Test;

import com.wallet.bean.BankAccount;
import com.wallet.dao.WalletDao;
import com.wallet.exception.WalletException;
import com.wallet.service.WalletService;

import junit.framework.Assert;
import junit.framework.TestCase;


public class WalletServiceTest extends TestCase {

	@Test
	public void testAddAccDao() {
		WalletDao w=new WalletDao();
		BankAccount a=new BankAccount();
		int b = w.accCreation(a);
		
		Assert.assertEquals(80004,b);
		
		BankAccount a1=new BankAccount();

		Assert.assertEquals(80005,w.accCreation(a1));
		
		BankAccount a2=new BankAccount();
		
		Assert.assertEquals(80006,w.accCreation(a2));
		
	}
@Test
	public void testDepositDao() {
		WalletService w= new WalletService();
		BankAccount a=new BankAccount();
		Assert.assertEquals(4000.00, w.depositDao(4000.00));
		Assert.assertEquals(2000.00, w.withdrawDao(2000.00));
	}
@Test
	public void testWithdrawDao()  {
		WalletService w= new WalletService();
		BankAccount a=new BankAccount();
		Assert.assertEquals(4000.00, w.depositDao(4000.00));
		Assert.assertEquals(3000.00, w.withdrawDao(1000.00));
		Assert.assertEquals(1000.00, w.withdrawDao(2000.00));
		
	}
@Test
	public void testShowBalDao() {
		WalletService w = new WalletService();
	BankAccount a=new BankAccount();
	Assert.assertEquals(0.00, w.showBalDao());
	
	}

@Test	
	public void testValidateCustName() {
	WalletService check=new WalletService();
	Assert.assertEquals(true, check.validateCustName("Dhoni"));
	}
@Test
	public void testValidateCustPhoneNumber() {
		WalletService check = new WalletService();
		Assert.assertEquals(true, check.validateCustPhoneNumber("8985769759"));
	}
@Test
	public void testValidateCustAge() {
		WalletService check = new WalletService();
		Assert.assertEquals(true, check.validateCustAge(30));
	}
@Test
	public void testValidateCustPwd() {
		WalletService check = new WalletService();
		Assert.assertEquals(true, check.validateCustPwd("Dhoni@123"));
	}
@Test
	public void testValidateAmt() {
		WalletService check = new WalletService();
		Assert.assertEquals(true, check.validateAmt(4000.00));
	}
@Test
	public void testCheckLogin() throws WalletException {
		WalletDao w =new WalletDao();
		BankAccount a = new BankAccount();
		w.accCreation(a);
		BankAccount a1 = new BankAccount();
		w.accCreation(a1);
		BankAccount a2 = new BankAccount();
		w.accCreation(a2);
		BankAccount a3 = new BankAccount();
		w.accCreation(a3);
		
		Assert.assertEquals(a1, w.loginUser(80001));
		
	}
@Test
	public void testValidateNameFail() {
	WalletService check=new WalletService();
	Assert.assertEquals(false, check.validateCustName("dhoni"));
	
	}
@Test
	public void testValidatePwdFail() {
		WalletService check =new WalletService();
		Assert.assertEquals(false, check.validateCustPwd("@dhoni1d"));
	}
@Test
	public void testValidateAgeFail() {
		WalletService check=new WalletService();
		Assert.assertEquals(false, check.validateCustAge(120));
	}
@Test
	public void testValidateAmtFail()
	{
		WalletService check=new WalletService();
		Assert.assertEquals(false, check.validateAmt(0.00));
	}

}
