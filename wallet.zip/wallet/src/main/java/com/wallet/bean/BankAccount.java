package com.wallet.bean;

import java.util.ArrayList;

public class BankAccount {
	
	private int accountNumber;
	private String custName;
	private String custPhoneNo;
	private int custAge;
	private double custBal;
	private String Transaction;
	
	
	public void setTransaction(String transaction) {
		Transaction = transaction;
	}
	static private int accNumGen = 80000;
	private String custPwd;
	ArrayList<String> tDetails = new ArrayList<String>();
	public ArrayList<String> gettDetails() {
		return tDetails;
	}
	public void settDetails(String getDetails) {
		this.tDetails.add(getDetails);
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber() {
		this.accountNumber = accNumGen++;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustPhoneNo() {
		return custPhoneNo;
	}
	public void setCustPhoneNo(String custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}
	public int getCustAge() {
		return custAge;
	}
	public void setCustAge(int custAge) {
		this.custAge = custAge;
	}
	public double getCustBal() {
		return custBal;
	}
	public void setCustBal(double custBal) {
		this.custBal = custBal;
	}
	public String getCustPwd() {
		return custPwd;
	}
	public void setCustPwd(String custPwd) {
		this.custPwd = custPwd;
	}
	public String getTransaction() {
		
		return Transaction;
	}
	public BankAccount(int accountNumber, String custName, String custPhoneNo, int custAge, double custBal,
			String transaction, String custPwd) {
		super();
		this.accountNumber = accountNumber;
		this.custName = custName;
		this.custPhoneNo = custPhoneNo;
		this.custAge = custAge;
		this.custBal = custBal;
		Transaction = transaction;
		this.custPwd = custPwd;
	}
	
	
	public BankAccount() {
	}
	}
	


