package com.wallet.dao;

import com.wallet.bean.BankAccount;
import com.wallet.exception.WalletException;

public interface IWalletDao {
	
	int accCreation(BankAccount a);
	
	BankAccount loginUser(int accNo) throws WalletException;
	
	void updateDetails(int accNo, BankAccount a);

}
