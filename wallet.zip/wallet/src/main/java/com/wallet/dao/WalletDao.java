package com.wallet.dao;

import java.util.TreeMap;

import com.wallet.bean.BankAccount;
import com.wallet.exception.WalletException;

public class WalletDao implements IWalletDao {
	TreeMap<Integer, BankAccount> map = new TreeMap<Integer, BankAccount>();
	
	@Override
	public int accCreation(BankAccount a) {
		a.setAccountNumber();
		map.put(a.getAccountNumber(), a);
		return a.getAccountNumber();
	}

	

	@Override
	public BankAccount loginUser(int accNo) throws WalletException {
		
		return  map.get(accNo);
	}

	@Override
	public void updateDetails(int accNo, BankAccount a) {
		map.replace(accNo, a);
		
	}

}
